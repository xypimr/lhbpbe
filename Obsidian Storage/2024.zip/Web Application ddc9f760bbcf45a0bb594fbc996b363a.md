# Web Application

### Ссылочки

1. https://timcore.ru/2022/09/29/kak-ustanovit-owasp-juice-shop-na-kali-linux-2022/ – `Установка OSWASP Juicy Shop`
2. https://github.com/juice-shop/juice-shop?tab=readme-ov-file#official-companion-guide
`Гайд juice shop`