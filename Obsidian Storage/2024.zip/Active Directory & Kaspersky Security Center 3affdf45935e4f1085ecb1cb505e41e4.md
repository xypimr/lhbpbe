# Active Directory & Kaspersky Security Center

1. Развертывание АD https://habr.com/ru/companies/testo_lang/articles/525326/
2. Подключение к домену Linux тачку – ? https://serverspace.ru/support/help/linux-active-directory/?utm_source=google.com&utm_medium=organic&utm_campaign=google.com&utm_referrer=google.com